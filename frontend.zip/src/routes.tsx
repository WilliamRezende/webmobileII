import React from 'react';

import { BrowserRouter, Route } from 'react-router-dom';

import CoachForm from './pages/CoachForm';
import CoachList from './pages/CoachList';
import Landing from './pages/Landing';

const Routes = () => {
  return (
    <BrowserRouter>
      <Route path="/" exact component={Landing} />
      <Route path="/study" component={CoachList} />
      <Route path="/give-classes" component={CoachForm} />
    </BrowserRouter>
  );
};

export default Routes;
